/*
 * Biblioteca_TP2.h
 *
 *  Created on: 28 sep. 2019
 *      Author: alumno
 */

#ifndef BIBLIOTECA_TP2_H_
#define BIBLIOTECA_TP2_H_

typedef struct
    {
        int idEmployee;
        char employeeName[51];
        char employeeLastName[51];
        float salary;
        int sector;
        int isEmpty;
    }sEmployee;

#endif /* BIBLIOTECA_TP2_H_ */
