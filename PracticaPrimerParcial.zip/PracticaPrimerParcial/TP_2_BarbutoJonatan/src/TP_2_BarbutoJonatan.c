/*
 ============================================================================
 Name        : TP_2_BarbutoJonatan.c
 Author      : Jonatan Barbuto
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayEmployees.h"


int main(void) {

	int FlagInit=0;
	int menuOpcionElegida;
	char menuPrincipalMensaje[] =
	                "\n1-Altas\
	                 \n2-Modificar\
	                 \n3-Baja\
	                 \n4-Informar";

	do
	{
			printf(menuPrincipalMensaje);
			scanf("%d",&menuOpcionElegida);

	        switch(menuOpcionElegida)
	        {
	        case 1: // ALTA ABONADO
	            //llamar a funcion;

	        	FlagInit=1;
	            break;
	        case 2: // MODIFICAR ABONADO
	            //llamar a funcion;
	        	if(FlagInit==1)
	        	{

	        	}
	            break;
	        case 3: // BAJA ABONADO
	            //llamar a funcion;
	        	if(FlagInit==1)
	        	{

	        	}
	            break;
	        case 4:	// LISTAR POR APPELLIDO O SALARIO Y PROMEDIO
	        	//llamar a funcion;
	        	if(FlagInit==1)
	        	{

	        	}
	        	break;

	        default:
	                 printf("\nNO ES UNA OPCION VALIDA!!!\n\n");

	                 break;
	        }

	 }while(menuOpcionElegida !=default);


	return 0
}
