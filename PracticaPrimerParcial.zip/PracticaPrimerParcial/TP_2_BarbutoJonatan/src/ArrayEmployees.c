/*
 * ArrayEmployees.c
 *
 *  Created on: 28 sep. 2019
 *      Author: alumno
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayEmployees.h"

int initEmployees(Employee* list, int len)
{
	int i;
	    for(i=0;i < LIMITE_EMPLOYEES; i++)
	    {
	        arrayPersonas[i].legajo = valor;
	    }
}

int addEmployee(Employee* list, int len, int id, char name[],char
lastName[],float salary,int sector)
{
	 indiceLugarLibre = buscarPrimerOcurrencia(arrayPersonas,QTY_PERSONAS,-1);
		                if(indiceLugarLibre == -1)
		                {
		                    printf("\n\nNO QUEDAN LUGARES LIBRES!!!\n");
		                    break;
		                }

		                printf("\nALTA\n");
		                if (!getStringLetras("Ingrese el nombre: ",auxiliarNombreStr))
		                {
		                    printf ("El nombre debe estar compuesto solo por letras\n");
		                    break;
		                }

		                if (!getStringLetras("Ingrese el apellido: ",auxiliarApellidoStr))
		                {
		                    printf ("El apellido debe estar compuesto solo por letras\n");
		                    break;
		                }

		                if (!getStringNumeros("Ingrese el legajo: ",auxiliarLegajoStr))
		                {
		                    printf ("El legajo debe ser numerico\n");
		                    break;
		                }

 return -1;
}

int findEmployeeById(Employee* list, int len,int id)
{


 return 0;
}


//Caso 3 borrar empleado
int removeEmployee(Employee* list, int len, int id)
{
	if (!getStringNumeros("Ingrese el legajo a dar de baja: ",auxiliarLegajoStr))
	{
		printf ("El legajo debe ser numerico\n");
		break;
	}
	indiceResultadoBusqueda = buscarPrimerOcurrencia(arrayPersonas,QTY_PERSONAS,atoi(auxiliarLegajoStr));

	if(indiceResultadoBusqueda == -1)
	{
		printf("\n\nNO SE ENCUENTRA ESE LEGAJO\n");
		break;
	}
		arrayPersonas[indiceResultadoBusqueda].legajo=-1;
		break;
}

int sortEmployees(Employee* list, int len, int order)
{




 return 0;
}

int printEmployees(Employee* list, int length)
{


 return 0;
}
//Listo promedio y salario//
int promEmployees(Employee* list,int length)
{
	int i;
	float sumSalario;
	float cantSalario=0;
	float promSalario;
	int superaSalario;

	for(i=0;i<length;i++)
	{
		if(list->isEmpty==0)
		{
			sumSalario=list->salary;
			cantSalario++;
		}
	}
	promSalario=sumSalario%cantSalario;

	for(i=0;i<length;i++)
	{
		if(list->salary>promSalario)
		{
			superaSalario++
		}
	}
	return 0;
}
//pasar a otra biblioteca
void inicializarArrayPersonas(Persona arrayPersonas[],int cantidadDeElementos,int valor)
{
    int i;
    for(i=0;i < cantidadDeElementos; i++)
    {
        arrayPersonas[i].legajo = valor;
    }
}

int buscarPrimerOcurrencia(Persona arrayPersonas[],int cantidadDeElementos,int valor)
{
    int i;
    for(i=0;i < cantidadDeElementos; i++)
    {
        if(arrayPersonas[i].legajo == valor)
        {
            return i;
        }
    }
    return -1;
}















